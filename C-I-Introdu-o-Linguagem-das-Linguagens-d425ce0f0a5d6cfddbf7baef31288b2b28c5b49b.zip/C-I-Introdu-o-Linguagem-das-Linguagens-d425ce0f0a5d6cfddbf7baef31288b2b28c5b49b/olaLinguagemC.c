#include <stdio.h>

int main() {
  printf("Ola linguagem C");
}